import ASocialIcon from './social-icon.js'
export { keyFor } from './networks'

export const SocialIcon = ASocialIcon
